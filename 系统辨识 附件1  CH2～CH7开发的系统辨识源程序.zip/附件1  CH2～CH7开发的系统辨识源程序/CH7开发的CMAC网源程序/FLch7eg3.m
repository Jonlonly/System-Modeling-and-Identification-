%CMAC����,���������ӳ���
%CMAC�ӳ���1
clear
w1=0.1;w2=0.0;w3=-0.1; w4=0.0
N=144;  N1=20; E=0.0;
b=0.062; k=0; i=0;
for k=1:N    
yp=2.5*cos(0.99*k);
for j=1:30
 wa=w1+w2+w3+w4;
 a=b*(1-k/N+1);
 w5=w4+a*[yp-wa];
w1=w2;
 w2=w3;
 w3=w4;
 w4=w5;
end
e=[(yp-wa).^2]/2;
sub1e(k)=e;
 yp1(k)=yp;
 sub1w(k)=wa;
end
sub1wz=sub1w;
 
 %CMAC�ӳ���2
w1=0.1;w2=0.0;w3=-0.1; w4=0.0;
 N=144; N1=20; E=0.0;
b=0.0612;
k=1; 
for k=1:N  
    
ypp=10/(pi*3)*cos(1.97*k);
for j=1:30
 wa=w1+w2+w3+w4;
 a=b*(1-k/N+1);
 w5=w4+a*[ypp-wa];
w1=w2;
 w2=w3;
 w3=w4;
 w4=w5;
end
e=[(ypp-wa).^2]/2;
sub2e(k)=e;
 yp2(k)=ypp;
 sub2w(k)=wa;
end
 sub2wz=sub2w;

%CMACг���ϳ��ӳ���
w1=0.1;w2=0.0;w3=-0.1; w4=0.0;
 N=144; N1=20; E=0.0;
b=0.0612;
k=1; 
for k=1:N  
   
ypp=2.5*cos(0.99*k)+10/(pi*3)*cos(1.97*k);
for j=1:30
 wa=w1+w2+w3+w4;
 a=b*(1-k/N+1);
 w5=w4+a*[ypp-wa];
w1=w2;
 w2=w3;
 w3=w4;
 w4=w5;
end
e=[(ypp-wa).^2]/2;
subze(k)=e;
 ypz(k)=ypp;
 subzw(k)=wa;
 end
subzwz=subzw;

 %��ͼ
 i=1:N
 subplot(4,1,1)
 plot(i,yp1,i,sub1w,'rx')
 ylabel('w1')
 legend('y1 ','w1 ')
 subplot(4,1,2)
 plot(i,yp2,i,sub2w,'rx')
 ylabel('w2')
 legend('y2 ','w2')
 

subplot(4,1,3)
 plot(i,ypz,i,subzw,'rx') 
 ylabel('wz')
legend('yz ','wz ')
subplot(4,1,4)
 plot(i,sub1e,'o',i,sub2e,'x',i,subze,'*') 
 %plot(i,sub1e,'x',i,sub2e,'o')
 xlabel('k')
 ylabel('e')
 legend('e1','e2','ez')