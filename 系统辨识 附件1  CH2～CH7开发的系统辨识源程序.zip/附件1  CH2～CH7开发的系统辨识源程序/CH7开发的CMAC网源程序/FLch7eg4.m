%CMAC����
clear
w1=-0.1;w2=0.0;w3=0.1; w4=-0.0;
N=180;  N1=20; E=0.0;
b=0.013; k=0; i=0;w4=0.1;w5=-0.2;w6=0.2; d=0.09;
for k=1:N    
p=pi*0.0056*k;
for i=1:N1
yp=5*sin(2*p)*1.2*exp(-i/260);
for j=1:6
 wa=w1+w2+w3+w4+w5+w6;
e=(yp-wa)
 a=b*(1-k/N);
 c=d*(1-k/N);
 wb=w6+a*[yp-wa];
  wc=w5+c*[yp-wa];
 w(k,i)=wa;
 e1(k,i)=e;
 ypp(k,i)=yp;

w1=w2;
 w2=w3;
 w3=w4;
 w4=w5;
 w5=wc;
 w6=wb;
end
end
% if e<=E, brreak, else, end 
end
w1=w;
yp1=ypp;
e2=e1
 %��ͼ
  subplot(3,1,1)
 mesh(ypp)
 zlabel('ypp')
 subplot(3,1,2)
 mesh(w)
 zlabel('w')
 subplot(3,1,3)
 mesh(e1)
 xlabel('k')
 ylabel('i')
 zlabel('e1')
 
 