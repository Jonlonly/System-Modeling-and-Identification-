w10ij=[.01 .01 .02; .1 .11 .02; .01 0 .1; .11 .01 .02;.1 .1 .02; .11 .1 .1;.1 .1 .1;0 .1 .1;.1 0 .1];     
w11ij=[.1 .2 .11; .02 .13 .04; .09 .08 .08; .09 .1 .06; .1 .11 .02; .06 0 .1;.1 .1 .1;0 .1 0;.1 .1 .1];     
w20j=[.01;.02;.1;.2;.1;.1;.1;.1;.1];    
w21j=[0; 0.1; .1; .02;0;.1;.1;.1;.1];
q0j=[.9 .8 .7 .6 .1 .2 .1 .1 .1];     
q120j=q0j;
q11j=[.5 .2 .3 .4 .1 .2 .1 .1 .1];
q12j=q11j;
w121ij=w20j*q0j;
w120ij=w20j*q11j;    
 f1=2;
q2j=0;                    % ��ֵ��ʼ��
p0=.2;
k1=1;
p1=.3;
w=0;
xj=[1 1 1];            % �������� 

error=0.0001;
a1=[1 1 1 1];
n=1;
e1=0; e0=0; e2=0; e3=0; e4=0; 
yo=0; ya=0; yb=0; y0=0; y1=0; y2=0; y3=0;
u=0; u1=0; u2=0.68; u3=.780; u4=u3-u2;
k1=1;
kn=28;
e3=.055; z1=0;
z12=0; q123j=0; t2j=0; o12j=0;r=0;r1=0; s=0.1;d2j=0;
%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   v1=randn(40,1);
for m=1:40
     G=0.1*v1(m);
 yn=.3366*y2+.4134*y1+0.28*u2+0.12*u1+s*G; %��ȡ����ʶϵͳ���
y1=y2;
y2=yn;
 yp=yn;
u0=u1;
u1=u2;
 ya(m)=yn;
    for  k=1:10
% �����һ�������
 for  i=1:9
   x1=[w11ij(i,1)*xj(:,1)]+[w11ij(i,2)*xj(:,2)]+[w11ij(i,3)*xj(:,3)];
   x=x1+q11j(:,i);
   o=1/[1+exp(-x)];
   o11j(i)=o;
  end
%����ڶ��������  
 for  i=1:9
 for  j=1:9
   z1=z1+w121ij(i,j)*o11j(:,j);
   end
   z=z1+q12j(:,i);
   o=1/[1+exp(-x)];
   o12j(i)=o;
  end
 % ���������
   for  i=1:9
   yb=yb+w21j(i,:)*o12j(:,i);
   end
   yi=yb+p1;
   y=1/[1+exp(-yi)];
   e0=e1;
   e1=e2;
   e2=[(yp-y).^2]/2;  % ����Ŀ��ֵ�����������֮������  
   e(k)=e2;
   xj1=e2;
  xj2=e1;         
   xj3=e0;          
   xj=[xj1 xj2 xj3]; 
 

  for   i=1:9   %������һ����Ȩֵ
      d1=o11j(:,i)*[1-o11j(:,i)]*d2j*w21j(i,:);  %�����1���������ź�
      do=o11j(:,i)*d1;
       qw=q11j(:,i)-q0j(:,i);
      q2j=q11j(:,i)+.8*do+.4*qw;
       q3j(:,i)=q2j;
   for j=1:3
      dw=w11ij(i,j)-w10ij(i,j);
      w12ij=w11ij(i,j)+.8*do*xj(j)+.6*dw;
      w13ij(i,j)=w12ij;
   end
  end      
      w10ij=w11ij;

      w11ij=w13ij;
       q0j=q11j;
      q11j=q3j;
  for   i=1:9  %�����ڶ�����Ȩֵ
      d1=o12j(:,i)*[1-o12j(:,i)]*d2j*w21j(i,:);%�����2���������ź�
      do=o12j(:,i)*d1;
       qw=q12j(:,i)-q120j(:,i);
      t2j=q12j(:,i)+.8*do+.4*qw;
       q123j(:,i)=t2j;
   for j=1:9
      dw=w121ij(i,j)-w120ij(i,j);
      w122ij=w121ij(i,j)+.8*do*o11j(j)+.6*dw;
       w123ij(i,j)=w122ij;
   end
  end      
      w120ij=w121ij;

      w121ij=w123ij;
       q120j=q12j;
      q12j=q123j;
 %��̬����ѧϰ����
 if  m<4,   r=0.2;  r1=0.0001  ;
else
r=0.14;   r1=0.005;
end
 for  i=1:9  %���������Ȩֵ
      d2j=y*(1-y)*(yp-y);  %������������ź�
      dw=w21j(i,:)-w20j(i,:);
      w22j=w21j(i,:)+r*d2j*o12j(i)+.4*dw+r1*e2;
      w23j(i,:)=w22j;    
  end
      w20j=w21j;
      w21j=w23j;
      ph=p1-p0;
      p2=p1+.96*(yp-y)+.58*ph+r1*e2;
      p0=p1;
      p1=p2;
     
 u=y;
if  e2<=.005  break;
else
     end
     end
 ya(m)=yp*f1;
 e3(m)=e2;
 ym(m)=y*f1;
 V(m)=G;
m6=m
end
     w11ij=w13ij
     w121ij=w123ij
     w21j=w23j
 subplot(3,1,1)  %��ͼ
 m=1:m6;
 plot(m,ya,m,ym,'rx'),
xlabel('k'),ylabel('ya , ym')
 legend('ya','ym'); %ͼ��ע
 subplot(3,1,2)
 m=1:m6;
 plot(m,e3),xlabel('k'),ylabel('e')
 subplot(3,1,3)
 m=1:m6;
plot(m,V)
xlabel('k'),ylabel('v')

